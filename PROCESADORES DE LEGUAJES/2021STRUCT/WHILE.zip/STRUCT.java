public class STRUCT extends Expresion {
    public STRUCT(String i,AST l){
        super(null,l);
        tipo=new Tipo(Tipo.STRUCT);
        palabra=i;if(der!=null){
            der.generarCTD(palabra);
        }
    }
    public void generarCTD(){
        
    }
}
