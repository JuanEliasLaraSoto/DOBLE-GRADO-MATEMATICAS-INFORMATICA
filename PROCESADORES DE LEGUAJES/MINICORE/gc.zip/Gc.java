import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase para la generación de código intermedio.
 */
public class Gc {

    // Lista que almacena las instrucciones generadas
    private List<String> instrucciones;

    /**
     * Constructor que inicializa la lista de instrucciones.
     */
    public Gc() {
        this.instrucciones = new ArrayList<>();
    }

    /**
     * Agrega una instrucción a la lista de instrucciones.
     *
     * @param instruccion La instrucción en formato de código intermedio.
     */
    public void agregarInstruccion(String instruccion) {
        instrucciones.add(instruccion);
    }

    /**
     * Genera una instrucción de asignación.
     *
     * @param destino Variable destino.
     * @param fuente Variable o valor fuente.
     */
    public void generarAsignacion(String id, String temp) {
        
        agregarInstruccion(id + " = " + temp + ";");
    }
    public void generarPrint(String exp) {
        
        agregarInstruccion("print " + exp+";");
    }

    /**
     * Genera una instrucción de operación binaria.
     *
     * @param destino Variable destino.
     * @param operando1 Primer operando.
     * @param operando2 Segundo operando.
     * @param operador Operador (e.g., +, -, *, /).
     */
    public void generarOperacion(String temp, String operando1, String operando2, String operador) {

        agregarInstruccion(temp + " = " + operando1 + " " + operador + " " + operando2 + ";");
    }

    /**
     * Genera una instrucción de salto condicional.
     *
     * @param condicion Condición del salto.
     * @param etiqueta Etiqueta de destino si se cumple la condición.
    */
    public void generarSaltoCondicional(String e1,String op,String e2, String etiqueta) {
        agregarInstruccion("if (" + e1+op+e2 + ") goto " + etiqueta + ";");
    }
         

    /**
     * Genera una instrucción de salto incondicional.
     *
     * @param etiqueta Etiqueta de destino.
     */
    public void generarSalto(String etiqueta) {
        agregarInstruccion("goto " + etiqueta + ";");
    }

    /**
     * Genera una etiqueta.
     *
     * @param etiqueta Nombre de la etiqueta.
     */
    public void generarEtiqueta(String etiqueta) {
        agregarInstruccion(etiqueta + ":");
    }

  

    /**
     * Genera una instrucción para convertir un entero a flotante.
     *
     * @param destino Variable destino para el valor convertido.
     * @param fuente Variable o valor fuente a convertir.
     */
    public void generarIntToFloat(String temp, String fuente) {
        agregarInstruccion(temp + " = inttoreal " + fuente + ";");
    }

    /**
     * Devuelve todas las instrucciones generadas.
     *
     * @return Lista de instrucciones generadas.
     */
    public List<String> obtenerInstrucciones() {
        return instrucciones;
    }

    /**
     * Imprime todas las instrucciones generadas.
     */
    public void imprimirInstrucciones() {
        for (String instruccion : instrucciones) {
            PLXC.out.println(instruccion);
        }
    }
/**
 * Imprime todas las instrucciones almacenadas en la lista al flujo proporcionado.
 *
 * @param out El flujo de salida (por ejemplo, un archivo o la consola).
 */
public void imprimirInstrucciones(PrintStream out) {
    for (String instruccion : instrucciones) {
        PLXC.out.println(instruccion);
    }
}

  
}
