public class DosEtq {
    public String si,no;

    public DosEtq(String si, String no) {
        this.si = si;
        this.no = no;
    }

    /**
     * public DosEtq(){
     * this.v=Main.nuevaEtq();
     * this.f=Main.nuevaEtq();
     * }
     */
    
}
