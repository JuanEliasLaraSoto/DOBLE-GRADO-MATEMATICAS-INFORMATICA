import java.io.FileReader;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.io.InputStreamReader;
import java.io.Reader;

public class PLXC {

    public static PrintStream out;

    public static void main(String args[]) {
        try {
            if (args.length == 0) {
                System.err.println("Usage: java PLXC <input_file> <output_file>, >ctd <output_file>, or <file.plx.ctd>");
                return;
            }

          if(args[0].endsWith(".plx.ctd")){
              
                String baseName = args[0].substring(0, args[0].lastIndexOf(".plx.ctd"));
                String inputFile = baseName + ".plx";
                String outputFile = baseName + ".ctd";

                Reader in = new FileReader(inputFile);
                out = new PrintStream(new FileOutputStream(outputFile));

                parser p = new parser(new Yylex(in));
                Object result = p.parse().value;

                // Assuming gc.imprimirInstrucciones() generates the output we want
            } else {
                // Input and output files from arguments
               
                String inputFile = args[0];
                String outputFile = args[1];
    
                Reader in = new FileReader(inputFile);
                out = new PrintStream(new FileOutputStream(outputFile));
    
                parser p = new parser(new Yylex(in));
                Object result = p.parse().value;
            } 

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (out != null) {
                out.close();
            }
        }
    }
}
