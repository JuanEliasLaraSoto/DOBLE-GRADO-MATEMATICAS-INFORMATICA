import java.util.HashMap;

public class TablaSimbolos {
	
	public final static String ERROR_NOEXISTE = "ERROR6: No se ha encontrado este indentificador en la tabla de simbolos";
	
	private static HashMap<String,Tipo> tabla = new HashMap<String,Tipo>();
	
	public static Tipo get(String id) {
		return tabla.get(id);
	}
	
	public static void put(String id, Tipo tipo) {
		tabla.put(id,tipo );
	}
	
}