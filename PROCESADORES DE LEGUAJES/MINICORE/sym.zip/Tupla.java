public class Tupla {
    public String codigo;
    public Tipo tipo;



    public Tupla(String codigo, Tipo tipo) {
        this.codigo = codigo;
        this.tipo = tipo;
    }
    public Tupla(Integer i, Tipo tipo) {
        this.codigo = i.toString();
        this.tipo = tipo;
    }
    public Tupla(Float i, Tipo tipo) {
        this.codigo = i.toString();
        this.tipo = tipo;
    }
}