public enum Tipo {
    I,
    F;

  
}