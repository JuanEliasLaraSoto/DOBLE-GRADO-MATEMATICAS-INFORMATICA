print("a\\c");
