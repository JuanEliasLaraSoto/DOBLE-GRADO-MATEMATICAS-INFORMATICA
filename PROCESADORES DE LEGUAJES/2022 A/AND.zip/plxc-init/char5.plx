print('\\');
print(1);
