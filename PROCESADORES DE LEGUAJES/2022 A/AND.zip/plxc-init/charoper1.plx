print('z'-'a');
