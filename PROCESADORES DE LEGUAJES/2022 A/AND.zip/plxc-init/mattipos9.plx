float x[3] ;
int y[3] ;
x[0] = 1.1;
x[1] = 2.2;
x[2] = 3.3;
y = x;
print(y[0]+y[1]+y[2]);

